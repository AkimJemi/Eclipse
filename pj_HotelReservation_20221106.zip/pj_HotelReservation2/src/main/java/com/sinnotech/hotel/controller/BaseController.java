package com.sinnotech.hotel.controller;

public class BaseController {
	// tiles root name
	protected final static String CLIENT_BASE_PATH = "client/";
	protected final static String ADMIN_BASE_PATH = "admin/";
}
