package com.sinnotech.hotel.dto;

import java.util.List;

public class ReservationDTO {
	private List<ReservationDTO> reservationDTOList;

	public List<ReservationDTO> getReservationDTOList() {
		return reservationDTOList;
	}

	public void setReservationDTOList(List<ReservationDTO> reservationDTOList) {
		this.reservationDTOList = reservationDTOList;
	}
	
}