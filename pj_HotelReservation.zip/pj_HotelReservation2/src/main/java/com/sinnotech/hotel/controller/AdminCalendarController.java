package com.sinnotech.hotel.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sinnotech.hotel.dto.Paging;
import com.sinnotech.hotel.dto.RoomDTO;
import com.sinnotech.hotel.dto.RoomInfoDTO;
import com.sinnotech.hotel.service.BookService;
import com.sinnotech.hotel.service.RoomService;
import com.sinnotech.hotel.util.PathCollection;

@Controller
@RequestMapping("admin/calendar")
public class AdminCalendarController extends BaseController implements PathCollection {
	private final String CALENDAR_BASE = ADMIN_BASE_PATH + BOOK$ + "adminCalendar";

	private String previousContent;

	@Autowired
	private BookService bookService;

	@Autowired
	private RoomService roomService;

	@RequestMapping("")
	public String calendar(Model model, Paging page) {
		roomSearch(page, model);
		return CALENDAR_BASE;
	}

	@RequestMapping("{roomID}")
	public String calendar(Model model, @PathVariable("roomID") Integer roomID, Paging page) {
		roomSearch(page, model);
		if (roomID != null) {
			model.addAttribute("roomInfo", roomService.searchRoomInfoDetailByRoomID(roomID));
			model.addAttribute("bookingDates", bookService.searchAvaliableBookDateByRoomID(roomID));
		}
		return CALENDAR_BASE;
	}

	@RequestMapping("calendarSelect")
	@ResponseBody
	public String calendarSelect(RoomInfoDTO roomInfo, Model model) {
		System.out.println("AdminCalendarController.CalendarSelect()");
		return null;
	}

	private RoomDTO roomSearch(Paging page, Model model) {
		RoomDTO roomInput;
		if (page == null || page.getCurrentPage() == null) {
			roomInput = roomService.getAllRoomInfoList(page);
		} else {
			if (previousContent != null && !previousContent.equals(page.getContent())) {
				page.setCurrentPage(1);
				page.setStartPage(1);
			}
			previousContent = page.getContent();
			roomInput = roomService.searchedRoomInfoList(page);
		}
		model.addAttribute("paging", roomInput.getPaging());
		model.addAttribute("roomInfoList", roomInput.getRoomInfoList());
		return roomInput;
	}

}
