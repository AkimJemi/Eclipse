package com.sinnotech.hotel.service;

import java.util.List;

import com.sinnotech.hotel.dto.TestDto;

public interface TestService {
	
	List<TestDto> finaAll();
}
