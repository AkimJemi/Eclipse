package com.sinnotech.hotel.util;

public  class Message {
	public final static String CANCEL_SUCCEED = "성공적으로 취소되었습니다.";
	public final static String DELETE_SUCCEED = "성공적으로 삭제되었습니다.";
	public final static String UPDATE_SUCCEED = "성공적으로 수정되었습니다.";
	public final static String CANCEL_FAIL = "취소가 실패하였습니다.";
	public final static String DELETE_FALL= "삭제가 실패하였습니다.";
	public final static String UPDATE_FAIL = "잘못된 정보로 수정이 실패하였습니다.";
	
	public final static String HTTPMethodError= "HttpServletRequest Method Error";

}
