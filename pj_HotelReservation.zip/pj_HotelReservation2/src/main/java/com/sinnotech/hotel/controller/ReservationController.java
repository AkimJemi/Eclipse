package com.sinnotech.hotel.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.sinnotech.hotel.dto.ReservationDTO;
import com.sinnotech.hotel.dto.TestDto;
import com.sinnotech.hotel.service.ReservationService;

@Controller
public class ReservationController extends BaseController {
	private final String ReservationLIST_FORM = CLIENT_BASE_PATH+"Reservation/ReservationList";
	
	@Autowired
	ReservationService ReservationService;
	
//	@RequestMapping("reservation")
//	public String Reservation(ReservationDTO ReservationDTO, Model model) {
//		List<ReservationDTO> ReservationDTOList = ReservationService.getReservationList();
//		model.addAttribute("ReservationList", ReservationDTOList);
//
//		return ReservationLIST_FORM;
//	}
	
	@RequestMapping(value = "reservation", method = RequestMethod.GET)
	public ModelAndView index() {
		
		
		ModelAndView model = new ModelAndView(ReservationLIST_FORM);
		return model;
	}
}