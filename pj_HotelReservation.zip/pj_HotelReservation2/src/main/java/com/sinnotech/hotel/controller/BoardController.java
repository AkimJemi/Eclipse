package com.sinnotech.hotel.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sinnotech.hotel.dao.BoardDAO;
import com.sinnotech.hotel.dto.BoardDTO;
import com.sinnotech.hotel.service.BoardService;

@Controller
public class BoardController extends BaseController {
	private final String BOARDLIST_FORM = CLIENT_BASE_PATH+"board/boardList";
	private final String GETBOARD_FORM = CLIENT_BASE_PATH+"board/getBoard";
	
	@Autowired
	BoardService boardService;
	
	// 전체 게시글 목록 보기
	@RequestMapping(value = "/board")
	public String BoardInit(BoardDTO boardDTO, Model model) {
		List<BoardDTO> boardDTOList = boardService.getBoardList();
		model.addAttribute("boardList", boardDTOList);
		return BOARDLIST_FORM;
	}
	
	// 해당 게시글 상세 보기
	@RequestMapping(value = "/getBoard")
	public String getBoard(BoardDTO boardDTO, Model model) {
		List<BoardDTO> boardDTOList = boardService.getBoard();
		model.addAttribute("getboard", boardDTOList);
		return GETBOARD_FORM;
	}
	
	// 게시글 수정
	@RequestMapping(value = "/updateBoard")
	public String updateBoard(BoardDTO boardDTO, BoardDAO boardDAO) {
		boardDAO.updateBoard(boardDTO);
		return BOARDLIST_FORM;
	}
	
	// 새 게시글 입력(게시글 등록)
	@RequestMapping(value = "/insertBoard")
	public String insertBoard(BoardDTO boardDTO, BoardDAO boardDAO) {
		boardDAO.insertBoard(boardDTO);
		return BOARDLIST_FORM;
	}
	
	// 게시글 삭제
	@RequestMapping(value = "/deleteBoard")
	public String deleteBoard(BoardDTO boardDTO, BoardDAO boardDAO) {
		boardDAO.deleteBoard(boardDTO);
		return BOARDLIST_FORM;
	}
}